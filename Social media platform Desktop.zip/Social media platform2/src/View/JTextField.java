package View;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import javax.swing.BorderFactory;

import java.awt.geom.RoundRectangle2D;

@SuppressWarnings("serial")
public class JTextField extends javax.swing.JTextField {

  private Shape shape;
	private String hint;
    

    public JTextField(String hint) {
        super();
        this.hint = hint;
        setFont(new Font("Segoe UI", Font.BOLD, 20));
        setOpaque(false);
        setText(hint);
        setForeground(GUIContants.textFieldHint); 
        setBorder(BorderFactory.createEmptyBorder(TOP, 20, BOTTOM, 20)); // Replace 0 with TOP and BOTTOM if defined
        
        addFocusListener(new FocusListener() {

            @Override
            public void focusLost(FocusEvent e) {
                if (getText().equals("")) {
                    setText(hint);
                    setForeground(GUIContants.textFieldHint); // Replace with GUIContants.textFieldHint if defined

                }
            }
                    @Override
                    public void focusGained(FocusEvent e) {
                        if (getText().equals(hint)) {
                            setText("");
                            setForeground(GUIContants.black); // Replace with GUIContants.black if defined             
                }
                
            }
        });
    }

    //FOR ROUNDED CORNERS
    
    protected void paintComponent(Graphics g) {
        g.setColor(GUIContants.white); 
        g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 45, 45);
        super.paintComponent(g);
    }

    // for rounded border
    protected void paintBorder(Graphics g) {
        g.setColor(GUIContants.white); // Replace with GUIContants.white if defined
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 45, 45);
    }

    
    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 45, 45);
        }
        return shape.contains(x, y);
    }
    public boolean isEmpty() {
    	return getText().equals(hint) || getText().equals("");
    	
    }
}
