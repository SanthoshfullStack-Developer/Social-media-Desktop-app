package View;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SideButton extends JPanel {

	private static final int IMAGE_WIDTH = 32; // Desired width
	private static final int IMAGE_HEIGHT = 32; // Desired height

	public SideButton(String text, String pic) {
		super(new FlowLayout(FlowLayout.LEFT, 10, 10));
		setMaximumSize(new Dimension(182, 50));
		setBackground(GUIContants.white);
		setCursor(new Cursor(Cursor.HAND_CURSOR));

		ImageIcon icon = loadIcon(pic);
		JLabel img = new JLabel(icon);
		add(img);

		// Create JLabel and configure it
		JLabel label = new JLabel(text);
		label.setFont(new Font("Segoe UI", Font.BOLD, 17)); // Set font size and style
		label.setForeground(GUIContants.textAreaHint);      // Set text color
		add(label);

		addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {}

			@Override
			public void mousePressed(MouseEvent e) {}

			@Override
			public void mouseExited(MouseEvent e) {
				setBackground(GUIContants.white);
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				setBackground(GUIContants.hover);
			}

			@Override
			public void mouseClicked(MouseEvent e) {}
		});
	}

	private ImageIcon loadIcon(String pic) {
		File webpFile = new File("pic/" + pic + ".webp");
		ImageIcon icon;

		if (webpFile.exists()) {
			icon = new ImageIcon(webpFile.getPath());
		} else {
			icon = new ImageIcon("pic/" + pic + ".png");
		}

		// Scale the image to desired dimensions
		Image img = icon.getImage();
		Image scaledImg = img.getScaledInstance(IMAGE_WIDTH, IMAGE_HEIGHT, Image.SCALE_SMOOTH);
		return new ImageIcon(scaledImg);
	}
}
