package Controller;

import java.sql.SQLException;
import Model.Database;
import View.Alert;

public class ChangePassword {
	
	private String password;
	private int ID;
	private Database database;
	
	// Fixed incorrect parameter assignment
	public ChangePassword(String password, int ID, Database database) { // Change 1
		this.ID = ID;
		this.password = password;
		this.database = database;
	}

	public boolean change() {
		boolean changed = false;
		
		// Fixed SQL syntax: removed unnecessary single quotes around column and table names
		String update = "UPDATE Users SET Password = '" + password + 
		                "' WHERE ID = " + ID + ";"; // Change 2
		
		try {
			database.getStatement().execute(update);
			changed = true;
		} catch (SQLException e) {
			new Alert(e.getMessage(), null);
			changed = false;
		}
		return changed;
	}
}
